//Triangle class takes a base and height, produces an area
var Triangle = /** @class */ (function () {
    //Creates a triangle instance given a base and height
    function Triangle(base, height) {
        this.base = base;
        this.height = height;
    }
    Triangle.prototype.getArea = function () {
        return this.base * this.height * 0.5;
    };
    return Triangle;
}());
var Rectangle = /** @class */ (function () {
    //Creates a rectangle instance given a width and length
    function Rectangle(length, width) {
        this.length = length;
        this.width = width;
    }
    //Returns the rectangles area from its with and length
    Rectangle.prototype.getArea = function () {
        return this.length * this.width;
    };
    return Rectangle;
}());
var Sphere = /** @class */ (function () {
    //Create Sphere instance from diameter
    function Sphere(diameter) {
        this.diameter = diameter;
    }
    //Returns the area of the Sphere
    Sphere.prototype.getArea = function () {
        return Math.PI * Math.pow(this.diameter * 0.5, 2);
    };
    return Sphere;
}());
var triangle = new Triangle(2.5, 5);
console.log("Area of triangle " + triangle.getArea());
var rectangle = new Rectangle(2.5, 5);
console.log("Area of rectangle " + rectangle.getArea());
var sphere = new Sphere(2.5);
console.log("Area of sphere " + sphere.getArea());
