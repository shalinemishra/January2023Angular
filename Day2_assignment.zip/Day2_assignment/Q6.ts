class foo {
    private userData: string = '';
    getbar(): string {
        return this.userData;
    }
    setbar(value: string) {
        this.userData = value;
    }

     test():void{
    var a = 0;
var e = 0;
var i = 0;
var o = 0; 
var u = 0;
var consonants = 0;
var count;

for (count = 0; count < this.userData.length; count++){
    var char = this.userData.charAt(count);
    if(char.match(/[aeiou]/)){
        switch (char) {
            case 'a':              
            case 'e':              
            case 'i':              
            case 'o':              
            case 'u':
             u++;
        }
    } else if(char.match(/[bcdfghjklmnpqrstvwxyz]/)) {
        consonants++;
    }
}


if(this.userData.charAt(0).match(/[aeiou]/))
console.log ("consonants: " + consonants);


else if(this.userData.charAt(0).match(/[bcdfghjklmnpqrstvwxyz]/))
console.log ("vowel: " + u);
    }
}
let f:foo=new foo();
f.setbar('ethis is tested');
f.test();