interface IShape {
    //All shapes must implement a getArea function to return an area as a number
    getArea(): number;
  }

  //Triangle class takes a base and height, produces an area
class Triangle implements IShape {
    //base and height properties remain public since the case is simple
    base: number;
    height: number;
    
    //Creates a triangle instance given a base and height
    constructor(base: number, height: number) {
      this.base = base;
      this.height = height;
    }
    getArea(): number {
      return this.base * this.height * 0.5;
    }
  }

  class Rectangle implements IShape {
    length: number;
    width: number;
    
    //Creates a rectangle instance given a width and length
    constructor(length: number, width: number) {
      this.length = length;
      this.width = width;
    }
    
    //Returns the rectangles area from its with and length
    getArea(): number {
      return this.length * this.width;
    }
  }

  class Sphere implements IShape {
    //Diameter property is private to allow radius methods
    private diameter: number;
    
    //Create Sphere instance from diameter
    constructor(diameter: number) {
      this.diameter = diameter;
    }
    
    //Returns the area of the Sphere
    getArea(): number {
      return Math.PI * Math.pow(this.diameter * 0.5, 2);
    }
}

let triangle:Triangle=new Triangle(2.5,5);
console.log("Area of triangle "+triangle.getArea());

let rectangle:Rectangle=new Rectangle(2.5,5);
console.log("Area of rectangle "+rectangle.getArea());

let sphere:Sphere=new Sphere(2.5);
console.log("Area of sphere "+sphere.getArea());