
var names = new Array("Mary", "Tom", "Jack", "Jillzczzc");
let dispalyName = (nameArr :string [])=>{
    for (var i = 0; i < nameArr.length; i++) {
      console.log(nameArr[i] + "  " +nameArr[i].length);
   }
}

dispalyName(names);