class Student2

{

     itemId:number;

     itemName:string;
     itemprice:number;
     category:string


    constructor(itemId:number,itemName:string,itemprice:number,category:string)

    {

           this.itemId=itemId;
           this.itemName=itemName;
           this.itemprice=itemprice;
           this.category=category;

    }

     public display()

    {
        console.log(this.itemId);
        console.log(this.itemName);
        console.log(this.itemprice);
        console.log(this.category);

    }




}

let student1:Student2=new Student2(1,'shaline',123,'A');
let student2:Student2=new Student2(1,'pankaj',345,'C');
student1.display();
student2.display();