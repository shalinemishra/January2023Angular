var names = new Array("Mary", "Tom", "Jack", "Jillzczzc");
var dispalyName = function (nameArr) {
    for (var i = 0; i < nameArr.length; i++) {
        console.log(nameArr[i] + "  " + nameArr[i].length);
    }
};
dispalyName(names);
