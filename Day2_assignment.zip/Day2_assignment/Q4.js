var Student2 = /** @class */ (function () {
    function Student2(itemId, itemName, itemprice, category) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemprice = itemprice;
        this.category = category;
    }
    Student2.prototype.display = function () {
        console.log(this.itemId);
        console.log(this.itemName);
        console.log(this.itemprice);
        console.log(this.category);
    };
    return Student2;
}());
var student1 = new Student2(1, 'shaline', 123, 'A');
var student2 = new Student2(1, 'pankaj', 345, 'C');
student1.display();
student2.display();
