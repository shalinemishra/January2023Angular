// program to check if the string is palindrome or not
function checkPalindrome(string1) {
    // find the length of a string
    var len = string1.length;
    // loop through half of the string
    for (var i = 0; i < len / 2; i++) {
        // check if first and last string are same
        if (string1[i] !== string1[len - 1 - i]) {
            return 'It is not a palindrome';
        }
    }
    return 'It is a palindrome';
}
// call the function
var value = checkPalindrome("tttr");
console.log(value);
